package com.example.aluno.myapplication;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.text.Html;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TabHost;
import android.widget.Toast;

import com.example.aluno.myapplication.adapters.MyFragmentPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {


    // parte do sobre
    private ViewPager mSlideViewPager;
    private LinearLayout mDotLayout;
    private TextView[] mDots;
    private SliderAdapter sliderAdapter;
    private Button mNextBtn;
    private Button mBackBtn;
    private int mCurrentPage;
    // fim da parte do sobre

    private TabLayout mTabLayout;
    private ViewPager mViewPager;
    private Button btnEntrada;
    private Button btnTelaCriar;
    private Button btnCriar;
    private Button btnEntrar;
    private Button btnMais;
    private Button btnVoltar;

    private Button btnEditarPerfil;
    private EditText edtUser;

    private int[] tabIcons = {
            R.drawable.casa,
            R.drawable.metas,
            R.drawable.perfil,
            R.drawable.ajuda,
            R.drawable.saida
    };

    ListView list;
    ListView lstMetas;
    SearchView searchView;
    String usuario;
    //CustomAdapter adapter;
    private ArrayAdapter<String> adapter;
    ArrayList<String> pessoa;
    ArrayAdapter adaptador;

    TextView txtnome;
    TextView txtuser;
    TextView txtbio;
    TextView txtdata;
    ImageView mage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sharedPreferences =  getBaseContext().getSharedPreferences("10lifegoals", Context.MODE_PRIVATE);
        usuario = sharedPreferences.getString("usuario", "Usário não encontrado");

        mTabLayout = (TabLayout) findViewById(R.id.tab_layout);
        mViewPager = (ViewPager) findViewById(R.id.view_pager);

        mViewPager.setAdapter(new MyFragmentPagerAdapter(getSupportFragmentManager(), getResources().getStringArray(R.array.titles_tab)));
        mTabLayout.setupWithViewPager(mViewPager);

        mTabLayout.getTabAt(0).setIcon(tabIcons[0]);
        mTabLayout.getTabAt(1).setIcon(tabIcons[1]);
        mTabLayout.getTabAt(2).setIcon(tabIcons[2]);
        mTabLayout.getTabAt(3).setIcon(tabIcons[3]);
        mTabLayout.getTabAt(4).setIcon(tabIcons[4]);
    }

    private void pesquisarUsuario(String pesquisa){
        final PessoaDAO dao = new PessoaDAO(this);
        final MetaDAO mdao = new MetaDAO(this);
        pessoa = dao.pesquisar(pesquisa, usuario);
        if(pessoa.isEmpty()){
            Toast.makeText(getBaseContext(),"Usuário não encontrado", Toast.LENGTH_SHORT).show();
        }else{
            setContentView(R.layout.pesquisa_usuario);
            list = (ListView) findViewById(R.id.listPesquisa);
            adapter = new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, pessoa);
            //adapter = new CustomAdapter(this, pessoa);
            list.setAdapter(adapter);

            list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    System.out.println(pessoa.get(i));
                    telaOutroUsuario(dao.buscarPessoa(pessoa.get(i)), mdao.procurarMetas(pessoa.get(i)));
                }
            });

        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        MenuItem lupa = menu.findItem(R.id.action_search);
        searchView = (SearchView) lupa.getActionView();
        searchView.setQueryHint("Pesquisar");
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                System.out.println("entrei aqui");
                pesquisarUsuario(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {

                System.out.println("entrei no change");
                return false;
            }
        });
        return true;
    }

    public void telaEditaPerfil(){
        setContentView(R.layout.editar_perfil);
    }

    /*public class SearchFiltro implements SearchView.OnQueryTextListener{

        @Override
        public boolean onQueryTextSubmit(String query) { //texto que for digitado lá
            return false; //ele trata de forma padrao
        }

        @Override
        public boolean onQueryTextChange(String newText) {
            return false;
        }
    } */

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();


        return super.onOptionsItemSelected(item);
    }

    public void telaOutroUsuario(Pessoa pessoa, ArrayList<String> metas){
        setContentView(R.layout.outro_usuario);

        lstMetas = (ListView) findViewById(R.id.listaMetasPerfil);
        txtnome = (TextView) findViewById(R.id.txtNome);
        txtuser= (TextView) findViewById(R.id.txtUsuario);
        txtbio = (TextView) findViewById(R.id.txtBio);
        txtdata = (TextView) findViewById(R.id.txtDataNasc);
        mage = (ImageView) findViewById(R.id.imageView);

        adaptador = new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_list_item_1, metas);
        lstMetas.setAdapter(adaptador);

        txtdata.setText(pessoa.getDataNasc());
        mage.setImageBitmap(pessoa.getImage());

        txtuser.setText(pessoa.getUsuario());
        txtnome.setText(pessoa.getNome());
        txtbio.setText(pessoa.getBio());

    }

    public void onBackPressed() {
        Intent intent = new Intent(MainActivity.this, MainActivity.class);
        startActivity(intent);

        return;
    }

}