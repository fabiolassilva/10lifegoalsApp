package com.example.aluno.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class MetaDAO {
    private static SQLiteDatabase bd;
    private CriaBanco openHelper;

    public MetaDAO(Context contexto){
        openHelper = new CriaBanco(contexto);
    }

    public void abrir(){
        bd = openHelper.getWritableDatabase();
    }

    public void fechar(){
        bd.close();
    }

    public Meta criarMeta(String descricao, String publica, int periodo, String situacao, String nomeUser){
        ContentValues valores = new ContentValues();
        valores.put("descricao", descricao);
        valores.put("publica", publica);
        valores.put("periodo", periodo);
        valores.put("situacao", situacao);
        valores.put("nomeUser", nomeUser);
        abrir();
        //long numero = bd.insert("meta", null, valores);
        bd.insert("meta", null, valores);
        fechar();
        Meta meta = new Meta();
        //meta.setNumero(numero);
        meta.setDescricao(descricao);
        meta.setPublica(publica);
        meta.setPeriodo(periodo);
        meta.setSituacao(situacao);
        meta.setNomeUser(nomeUser);
        return meta;
    }

    public ArrayList<String> procurarMetas(String usuario){
        ArrayList<String> metas = new ArrayList<String>();
        String[] campos =  {"nomeUser", "descricao"};
        String where = "nomeUser" + "= '" + usuario +"'";
        abrir();
        Cursor cursor = bd.rawQuery("Select descricao from meta where nomeUser=?", new String[]{""+usuario});
        while(cursor.moveToNext()){
            metas.add(cursor.getString(cursor.getColumnIndex("descricao")));
        }

        cursor.close();
        fechar();
        return metas;
    }

    public List<Meta> lerMetas(String usuario){
        List<Meta>metas = new ArrayList<>();
        abrir();
        Cursor cursor = bd.rawQuery("Select * from meta where nomeUser=?", new String[]{""+usuario});
        while(cursor.moveToNext()){
            Meta i = new Meta();
            i.setNumero(cursor.getLong(0));
            i.setDescricao(cursor.getString(1));
            i.setPublica(cursor.getString(2));
            i.setPeriodo(cursor.getInt(3));
            i.setSituacao(cursor.getString(4));
            i.setNomeUser(cursor.getString(5));
            metas.add(i);

        }
        cursor.close();
        fechar();
        return metas;

    }

    public ArrayList<String> procurarNum(String usuario){
        ArrayList<String> metas = new ArrayList<String>();
        //String[] campos =  {"nomeUser", "num"};
        //String where = "nomeUser" + "= '" + usuario +"'";
        abrir();
        Cursor cursor = bd.rawQuery("Select numero from meta where nomeUser=?", new String[]{""+usuario});
        while(cursor.moveToNext()){
            metas.add(cursor.getString(cursor.getColumnIndex("numero")));
        }

        cursor.close();
        fechar();
        return metas;
    }

    //que na verdade atualiza a sitauacao das metas
    public void remover(String usuario, int num){
        ContentValues values = new ContentValues();
        values.put("nomeUser", usuario);
        values.put("numero", num);
        values.put("situacao", "C");

        String[] selectionArgs =  {""+usuario, ""+num};
        // String where = "usuario" + "= '" + user +"'";
        bd = openHelper.getReadableDatabase();
        int count = bd.update("meta", values, "nomeUser=? and numero=?", selectionArgs);
        fechar();
    }

    public ArrayList<Meta> metasHome(String usuario){
        ArrayList<Meta> metas = new ArrayList<Meta>();
        String[] campos =  {"nomeUser", "descricao"};
        String where = "nomeUser" + "!= '" + usuario +"'";
        abrir();
        Cursor cursor = bd.rawQuery("Select descricao, nomeUser from meta where publica='sim' AND nomeUser!=? ORDER BY RANDOM() LIMIT 20" , new String[]{""+usuario});
        while(cursor.moveToNext()){
            Meta m = new Meta();
            m.setDescricao(cursor.getString(cursor.getColumnIndex("descricao")));
            m.setNomeUser(cursor.getString(cursor.getColumnIndex("nomeUser")));
            metas.add(m);
        }

        cursor.close();
        fechar();
        return metas;
    }


}
