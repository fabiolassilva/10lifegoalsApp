package com.example.aluno.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Created by Aluno on 20/08/2018.
 */

public class TelaHome extends Fragment {


    private ListView listView;
    //salvar meta

    private TextView txtDescrMeta;
    @Nullable
    @Override
    public View onCreateView(final LayoutInflater inflater, final ViewGroup container, Bundle savedInstanceState){
        final View rootView = inflater.inflate(R.layout.inicio, container, false);

        listView = (ListView)rootView.findViewById(R.id.listaHome);
        ArrayAdapter adapter = new TelaInicio(this.getActivity(), adcMetas());
        listView.setAdapter(adapter);


        return rootView;
    }




    private ArrayList<Meta> adcMetas(){
        SharedPreferences sharedPreferences =  getContext().getSharedPreferences("10lifegoals", Context.MODE_PRIVATE);
        String usuario = sharedPreferences.getString("usuario", "Usuário não encontrado");
        MetaDAO mdao = new MetaDAO(getActivity());
        ArrayList<Meta> meta = new ArrayList<Meta>();
        meta = mdao.metasHome(usuario);

        return meta;
    }
}
