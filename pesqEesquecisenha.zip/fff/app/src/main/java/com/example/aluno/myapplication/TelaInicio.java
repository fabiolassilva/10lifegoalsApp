package com.example.aluno.myapplication;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class TelaInicio extends ArrayAdapter<Meta> {
    private final Context context;
    private final ArrayList<Meta> meta;
    private SalvaDAO sdao;
    TextView txtNomeUsu;
    TextView txtDescrMeta ;
    Button btnSalvar;


    public TelaInicio(Context context, ArrayList<Meta> metas){
        super(context,R.layout.linha_inicio, metas);
        this.context = context;
        this.meta = metas;

    }

    public View getView(int position, View convertView, ViewGroup parent){
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.linha_inicio,parent,false);

        txtNomeUsu = (TextView) rowView.findViewById(R.id.txtNomeUsu);
        txtDescrMeta = (TextView) rowView.findViewById(R.id.txtDescMeta);

        txtNomeUsu.setText(meta.get(position).getNomeUser());
        txtDescrMeta.setText(meta.get(position).getDescricao());
        btnSalvar = (Button)rowView.findViewById(R.id.btnSalvar);
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarMeta();
            }
        });
        return rowView;
    }

    ///salvar meta inicio
    public void salvarMeta(){
        sdao = new SalvaDAO(getContext());
        sdao.abrir();


        String usuarioCriador;
        String descrMeta;
        String usuarioLogado;


        SharedPreferences sharedPreferences =  getContext().getSharedPreferences("10lifegoals", Context.MODE_PRIVATE);
        String usuarioLog = sharedPreferences.getString("usuario", "Usuário não encontrado");

        usuarioLogado= usuarioLog;

        usuarioCriador = txtNomeUsu.getText().toString();
        descrMeta = txtDescrMeta.getText().toString();

        PessoaSalvaMeta psm = sdao.salvar(usuarioLogado, usuarioCriador, descrMeta);

        ArrayAdapter<PessoaSalvaMeta> adaptador = new ArrayAdapter<PessoaSalvaMeta>(getContext().getApplicationContext(), 0);
        adaptador.add(psm);
        adaptador.notifyDataSetChanged();


        SharedPreferences.Editor editor;
        editor = sharedPreferences.edit(); //Escrever dentro do arquivo

        editor.putString("usuarioLogado", usuarioLogado);
        editor.putString("usuarioCriador", usuarioCriador);
        editor.putString("descrMeta", descrMeta);
        editor.commit();


        Toast.makeText(getContext(),"Meta Salva", Toast.LENGTH_SHORT).show();
    }

    //salvsar meta fim
}
