package com.example.aluno.myapplication;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TabHost;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Aluno on 20/08/2018.
 */

public class TelaMetas extends Fragment {
    TabHost tabHost;
    private TextView edm1;
    private TextView edm2;
    private TextView edm3;
    private TextView edm4;
    private TextView edm5;
    private TextView edm6;
    private TextView edm7;
    private TextView edm8;
    private TextView edm9;
    private TextView edm10;
    private TextView txtC;


    private TextView txp1;
    private TextView txp2;
    private TextView txp3;
    private TextView txp4;
    private TextView txp5;
    private TextView txp6;
    private TextView txp7;
    private TextView txp8;
    private TextView txp9;
    private TextView txp10;

    private CheckBox cb1;
    private CheckBox cb2;
    private CheckBox cb3;
    private CheckBox cb4;
    private CheckBox cb5;
    private CheckBox cb6;
    private CheckBox cb7;
    private CheckBox cb8;
    private CheckBox cb9;
    private CheckBox cb10;

    private Context context;
    private ListView lstConcluida;
    private List<String> concluidas;
    private ArrayAdapter<String> adaptador1;
    final String c0=null;
    final String c1=null;
    final String c2=null;
    final String c3=null;
    final String c4=null;
    final String c5=null;
    final String c6=null;
    final String c7=null;
    final String c8=null;
    final String c9=null;

    private Button novaM;
    int na = 0;

    private ListView listaSalvas;
    private List<String> metasalvas;
    private ArrayAdapter<String> adaptador;

    MetaDAO mdao;
    ArrayList<String> num =new ArrayList<>();

    @Override
    public void onAttach(Context context){
        this.context = context;
        super.onAttach(context);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState){
        final View rootView = inflater.inflate(R.layout.metas, container, false);

        //telametas
        tabHost = (TabHost) rootView.findViewById(R.id.tabHost);
        tabHost.setup();

        //tab1
        TabHost.TabSpec spec = tabHost.newTabSpec("Atuais");
        spec.setContent(R.id.Atuais);
        spec.setIndicator("Atuais");
        tabHost.addTab(spec);


        //tab2
        spec = tabHost.newTabSpec("Concluídas");
        spec.setContent(R.id.Concluídas);
        spec.setIndicator("Concluídas");
        tabHost.addTab(spec);

        //tab2
        spec = tabHost.newTabSpec("Salvas");
        spec.setContent(R.id.Salvas);
        spec.setIndicator("Salvas");
        tabHost.addTab(spec);

        lstConcluida = (ListView)rootView.findViewById(R.id.listaConcluida);

        //parte do adicionar meta
        novaM = (Button) rootView.findViewById(R.id.novaM);

        txtC = (TextView) rootView.findViewById(R.id.txtC);
        //AQUI COMECA A TENTATIVA DE MOSTRAR AS METAS
        edm1 = (TextView) rootView.findViewById(R.id.m1);
        edm2 = (TextView) rootView.findViewById(R.id.m2);
        edm3 = (TextView) rootView.findViewById(R.id.m3);
        edm4 = (TextView) rootView.findViewById(R.id.m4);
        edm5 = (TextView) rootView.findViewById(R.id.m5);
        edm6 = (TextView) rootView.findViewById(R.id.m6);
        edm7 = (TextView) rootView.findViewById(R.id.m7);
        edm8 = (TextView) rootView.findViewById(R.id.m8);
        edm9 = (TextView) rootView.findViewById(R.id.m9);
        edm10 = (TextView) rootView.findViewById(R.id.m10);

        txp1 = (TextView) rootView.findViewById(R.id.p1);
        txp2 = (TextView) rootView.findViewById(R.id.p2);
        txp3 = (TextView) rootView.findViewById(R.id.p3);
        txp4 = (TextView) rootView.findViewById(R.id.p4);
        txp5 = (TextView) rootView.findViewById(R.id.p5);
        txp6 = (TextView) rootView.findViewById(R.id.p6);
        txp7 = (TextView) rootView.findViewById(R.id.p7);
        txp8 = (TextView) rootView.findViewById(R.id.p8);
        txp9 = (TextView) rootView.findViewById(R.id.p9);
        txp10 = (TextView) rootView.findViewById(R.id.p10);

        cb1 = (CheckBox) rootView.findViewById(R.id.s1);
        cb2 = (CheckBox) rootView.findViewById(R.id.s2);
        cb3 = (CheckBox ) rootView.findViewById(R.id.s3);
        cb4 = (CheckBox ) rootView.findViewById(R.id.s4);
        cb5 = (CheckBox ) rootView.findViewById(R.id.s5);
        cb6 = (CheckBox ) rootView.findViewById(R.id.s6);
        cb7 = (CheckBox ) rootView.findViewById(R.id.s7);
        cb8 = (CheckBox ) rootView.findViewById(R.id.s8);
        cb9 = (CheckBox ) rootView.findViewById(R.id.s9);
        cb10 = (CheckBox) rootView.findViewById(R.id.s10);

        final SharedPreferences sharedPreferences =  getContext().getSharedPreferences("10lifegoals", Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor;
        editor = sharedPreferences.edit(); //Escrever dentro do arquivo
        final String usuario = sharedPreferences.getString("usuario", "Usuário não encontrado");

        final String m1 = sharedPreferences.getString("meta 0", "Meta não encontrada");
        final String m2 = sharedPreferences.getString("meta 1", "Meta não encontrada");
        final String m3 = sharedPreferences.getString("meta 2", "Meta não encontrada");
        final String m4 = sharedPreferences.getString("meta 3", "Meta não encontrada");
        final String m5 = sharedPreferences.getString("meta 4", "Meta não encontrada");
        final String m6 = sharedPreferences.getString("meta 5", "Meta não encontrada");
        final String m7 = sharedPreferences.getString("meta 6", "Meta não encontrada");
        final String m8 = sharedPreferences.getString("meta 7", "Meta não encontrada");
        final String m9 = sharedPreferences.getString("meta 8", "Meta não encontrada");
        final String m10 = sharedPreferences.getString("meta 9", "Meta não encontrada");

        final String c0 = sharedPreferences.getString("concluida 0", "Meta não encontrada");
        final String c1 = sharedPreferences.getString("concluida 1", "Meta não encontrada");
        final String c2 = sharedPreferences.getString("concluida 2", "Meta não encontrada");
        final String c3 = sharedPreferences.getString("concluida 3", "Meta não encontrada");
        final String c4 = sharedPreferences.getString("concluida 4", "Meta não encontrada");
        final String c5 = sharedPreferences.getString("concluida 5", "Meta não encontrada");
        final String c6 = sharedPreferences.getString("concluida 6", "Meta não encontrada");
        final String c7 = sharedPreferences.getString("concluida 7", "Meta não encontrada");
        final String c8 = sharedPreferences.getString("concluida 8", "Meta não encontrada");
        final String c9 = sharedPreferences.getString("concluida 9", "Meta não encontrada");

        String p1 = sharedPreferences.getString("pe 0", "Período não encontrado");
        String p2 = sharedPreferences.getString("pe 1", "Período não encontrado");
        String p3 = sharedPreferences.getString("pe 2", "Período não encontrado");
        String p4 = sharedPreferences.getString("pe 3", "Período não encontrado");
        String p5 = sharedPreferences.getString("pe 4", "Período não encontrado");
        String p6 = sharedPreferences.getString("pe 5", "Período não encontrado");
        String p7 = sharedPreferences.getString("pe 6", "Período não encontrado");
        String p8 = sharedPreferences.getString("pe 7", "Período não encontrado");
        String p9 = sharedPreferences.getString("pe 8", "Período não encontrado");
        String p10 = sharedPreferences.getString("pe 9", "Período não encontrado");

        novaM.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showInputDialog(context, usuario);
            }
        });

        mdao = new MetaDAO(getContext());
        num = mdao.procurarNum(usuario);
        concluidas = new ArrayList<String>();
        lstConcluida.requestLayout();
        cb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(cb1.isChecked()) {
                    System.out.println("entrei no if de check");
                    mdao.remover(usuario, Integer.parseInt(num.get(0)));
                    //editor.remove("meta 0");
                    concluidas(m6, 0);
                    //editor.putString("concluida 0", m1);
                    edm1.setText("Meta concluída");
                    editor.putString("meta 0","Meta concluída");
                    txp1.setText("");
                    editor.putString("pe 0", "");
                    cb1.setVisibility(View.INVISIBLE);
                    txtC.setVisibility(View.INVISIBLE);
                    //voltar();
                    editor.commit();
                    final String c0 = sharedPreferences.getString("concluida 0", "Meta não encontrada");
                    concluidas.add(c0);
                    lstConcluida.requestLayout();
                    novaMeta(0);

                }
            }
        });

        cb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb2.isChecked()) {
                    mdao.remover(usuario, Integer.parseInt(num.get(1)));
                    //editor.remove("meta 1");
                    //editor.putString("concluida 1", m2);
                    concluidas(m2,1);
                    edm2.setText("Meta concluída");
                    editor.putString("meta 1","Meta concluída");
                    editor.putString("pe 1", "");
                    txp2.setText("");
                    cb2.setVisibility(View.INVISIBLE);
                    txtC.setVisibility(View.INVISIBLE);
                    //voltar();
                    editor.commit();
                    final String c1 = sharedPreferences.getString("concluida 1", "Meta não encontrada");
                    concluidas.add(c1);
                    lstConcluida.requestLayout();
                    novaMeta(1);

                }
            }
        });

        cb3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb3.isChecked()) {
                    mdao.remover(usuario, Integer.parseInt(num.get(2)));
                    //editor.remove("meta 2");
                    //editor.putString("concluida 2", m3);
                    concluidas(m3,2);
                    edm3.setText("Meta concluída");
                    editor.putString("meta 2","Meta concluída");
                    editor.putString("pe 2", "");
                    txp3.setText("");
                    cb3.setVisibility(View.INVISIBLE);
                    txtC.setVisibility(View.INVISIBLE);
                    //voltar();
                    editor.commit();
                    String c2 = sharedPreferences.getString("concluida 2", "Meta não encontrado");
                    concluidas.add(c2);
                    lstConcluida.requestLayout();
                    novaMeta(2);
                }
            }
        });

        cb4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb4.isChecked()) {
                    mdao.remover(usuario, Integer.parseInt(num.get(3)));
                    //editor.remove("meta 3");
                    //editor.putString("concluida 3", m4);
                    concluidas(m4,3);
                    edm4.setText("Meta concluída");
                    txp4.setText("");
                    editor.putString("meta 3","Meta concluída");
                    editor.putString("pe 3", "");
                    cb4.setVisibility(View.INVISIBLE);
                    txtC.setVisibility(View.INVISIBLE);
                    //voltar();
                    editor.commit();
                    String c3 = sharedPreferences.getString("concluida 3", "Meta não encontrado");
                    concluidas.add(c3);
                    lstConcluida.requestLayout();
                    novaMeta(3);
                }
            }
        });

        cb5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb5.isChecked()) {
                    mdao.remover(usuario, Integer.parseInt(num.get(4)));
                    //editor.remove("meta 4");
                    //editor.putString("concluida 4", m5);
                    concluidas(m5,4);
                    edm5.setText("Meta concluída");
                    txp5.setText("");
                    cb5.setVisibility(View.INVISIBLE);
                    editor.putString("meta 4","Meta concluída");
                    editor.putString("pe 4", "");
                    //voltar();
                    txtC.setVisibility(View.INVISIBLE);
                    editor.commit();
                    String c4 = sharedPreferences.getString("concluida 4", "Meta não encontrado");
                    concluidas.add(c4);
                    lstConcluida.requestLayout();
                    novaMeta(4);
                }
            }
        });

        cb6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb6.isChecked()) {
                    mdao.remover(usuario, Integer.parseInt(num.get(5)));
                    //editor.remove("meta 5");
                    //editor.putString("concluida 5", m6);
                    concluidas(m6,5);
                    edm6.setText("Meta concluída");
                    txp6.setText("");
                    editor.putString("meta 5","Meta concluída");
                    cb6.setVisibility(View.INVISIBLE);
                    editor.putString("pe 5", "");
                    // voltar();
                    txtC.setVisibility(View.INVISIBLE);
                    editor.commit();
                    String c5 = sharedPreferences.getString("concluida 5", "Meta não encontrado");
                    concluidas.add(c5);
                    lstConcluida.requestLayout();
                    novaMeta(5);
                }
            }
        });

        cb7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb7.isChecked()) {
                    mdao.remover(usuario, Integer.parseInt(num.get(6)));
                    //editor.remove("meta 6");
                    editor.putString("pe 6", "");
                    //editor.putString("concluida 6", m7);
                    concluidas(m7,6);
                    edm7.setText("Meta concluída");
                    txp7.setText("");
                    cb7.setVisibility(View.INVISIBLE);
                    //voltar();
                    editor.putString("meta 6","Meta concluída");
                    txtC.setVisibility(View.INVISIBLE);
                    editor.commit();
                    String c6 = sharedPreferences.getString("concluida 6", "Meta não encontrado");
                    concluidas.add(c6);
                    lstConcluida.requestLayout();
                    novaMeta(6);
                }
            }
        });

        cb8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb8.isChecked()) {
                    mdao.remover(usuario, Integer.parseInt(num.get(7)));
                    //editor.remove("meta 7");
                    //editor.putString("concluida 7", m8);
                    concluidas(m8,7);
                    edm8.setText("Meta concluída");
                    txp8.setText("");
                    cb8.setVisibility(View.INVISIBLE);
                    editor.putString("meta 7","Meta concluída");
                    editor.putString("pe 7", "");
                    //voltar();
                    txtC.setVisibility(View.INVISIBLE);
                    editor.commit();
                    String c7 = sharedPreferences.getString("concluida 7", "Meta não encontrado");
                    concluidas.add(c7);
                    lstConcluida.requestLayout();
                    novaMeta(7);
                }
            }
        });

        cb9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb9.isChecked()) {
                    mdao.remover(usuario, Integer.parseInt(num.get(8)));
                    //editor.remove("meta 8");
                    //editor.putString("concluida 8", m9);
                    concluidas(m9,8);
                    edm9.setText("Meta concluída");
                    txp9.setText("");
                    editor.putString("meta 8","Meta concluída");
                    editor.putString("pe 8", "");
                    cb9.setVisibility(View.INVISIBLE);
                    // voltar();
                    txtC.setVisibility(View.INVISIBLE);
                    editor.commit();
                    String c8 = sharedPreferences.getString("concluida 8", "Meta não encontrado");
                    concluidas.add(c8);
                    lstConcluida.requestLayout();
                    novaMeta(8);
                }
            }
        });

        cb10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (cb10.isChecked()) {
                    mdao.remover(usuario, Integer.parseInt(num.get(9)));
                    //editor.remove("meta 9");
                    //editor.putString("concluida 9", m10);
                    concluidas(m10,9);
                    edm10.setText("Meta concluída");
                    txp10.setText("");
                    cb10.setVisibility(View.INVISIBLE);
                    //voltar();
                    txtC.setVisibility(View.INVISIBLE);
                    editor.putString("meta 9","Meta concluída");
                    editor.putString("pe 9", "");
                    editor.commit();
                    String c9 = sharedPreferences.getString("concluida 9", "Meta não encontrado");
                    concluidas.add(c9);
                    lstConcluida.requestLayout();
                    novaMeta(9);

                }
            }
        });

        editor.commit();

        edm1.setText(m1);

        if(edm1.getText().toString().equals("Meta concluída")){
            cb1.setVisibility(View.INVISIBLE);
            txtC.setVisibility(View.INVISIBLE);
            txp1.setText("");
            concluidas.add(c0);
            lstConcluida.requestLayout();
        }

        edm2.setText(m2);

        if(edm2.getText().toString().equals("Meta concluída")) {
            cb2.setVisibility(View.INVISIBLE);
            txtC.setVisibility(View.INVISIBLE);
            concluidas.add(c1);
            txp2.setText("");
            lstConcluida.requestLayout();
        }

        edm3.setText(m3);
        if(edm3.getText().toString().equals("Meta concluída")) {
            cb3.setVisibility(View.INVISIBLE);
            txtC.setVisibility(View.INVISIBLE);
            txp3.setText("");;
            concluidas.add(c2);
            lstConcluida.requestLayout();
        }

        edm4.setText(m4);
        if(edm4.getText().toString().equals("Meta concluída")) {
            cb4.setVisibility(View.INVISIBLE);
            txtC.setVisibility(View.INVISIBLE);
            txp4.setText("");
            concluidas.add(c3);
            lstConcluida.requestLayout();
        }

        edm5.setText(m5);
        if(edm5.getText().toString().equals("Meta concluída")) {
            cb5.setVisibility(View.INVISIBLE);
            txtC.setVisibility(View.INVISIBLE);
            txp5.setText("");
            concluidas.add(c4);
            lstConcluida.requestLayout();
        }

        edm6.setText(m6);
        if(edm6.getText().toString().equals("Meta concluída")) {
            cb6.setVisibility(View.INVISIBLE);
            txtC.setVisibility(View.INVISIBLE);
            txp6.setText("");
            concluidas.add(c5);
            lstConcluida.requestLayout();
        }
        edm7.setText(m7);
        if(edm7.getText().toString().equals("Meta concluída")) {
            cb7.setVisibility(View.INVISIBLE);
            txtC.setVisibility(View.INVISIBLE);
            txp7.setText("");
            concluidas.add(c6);
            lstConcluida.requestLayout();
        }

        edm8.setText(m8);
        if(edm8.getText().toString().equals("Meta concluída")) {
            cb8.setVisibility(View.INVISIBLE);
            txtC.setVisibility(View.INVISIBLE);
            txp8.setText("");
            concluidas.add(c7);
            lstConcluida.requestLayout();
        }

        edm9.setText(m9);
        if(edm9.getText().toString().equals("Meta concluída")) {
            cb9.setVisibility(View.INVISIBLE);
            txtC.setVisibility(View.INVISIBLE);
            txp9.setText("");
            concluidas.add(c8);
            lstConcluida.requestLayout();
        }

        edm10.setText(m10);
        if(edm10.getText().toString().equals("Meta concluída")) {
            cb10.setVisibility(View.INVISIBLE);
            txtC.setVisibility(View.INVISIBLE);
            txp10.setText("");
            concluidas.add(c9);
            lstConcluida.requestLayout();
        }

        if(!txp1.equals(""))
            txp1.setText(p1);
        if(!txp2.equals(""))
            txp2.setText(p2);
        if(!txp3.equals(""))
            txp3.setText(p3);
        if(!txp4.equals(""))
            txp4.setText(p4);
        if(!txp5.equals(""))
            txp5.setText(p5);
        if(!txp6.equals(""))
            txp6.setText(p6);
        if(!txp7.equals(""))
            txp7.setText(p7);
        if(!txp8.equals(""))
            txp8.setText(p8);
        if(!txp9.equals(""))
            txp9.setText(p9);
        if(!txp10.equals(""))
            txp10.setText(p10);
        //TERMINA AQUI A PARADA

        adaptador1 = new ArrayAdapter<String>(context, android.R.layout.simple_list_item_1, concluidas);
        lstConcluida.setAdapter(adaptador1);

        listaSalvas = (ListView) rootView.findViewById(R.id.listaMetasSalvas);
        listaSalvas.requestLayout();
        ArrayAdapter adapter = new TelaSalvas(this.getActivity(), mostrarSalvas());
        listaSalvas.requestLayout();
        listaSalvas.setAdapter(adapter);
        listaSalvas.requestLayout();


        return rootView;
    }

    private ArrayList<PessoaSalvaMeta> mostrarSalvas(){
        SharedPreferences sharedPreferences =  getContext().getSharedPreferences("10lifegoals", Context.MODE_PRIVATE);
        String usuario = sharedPreferences.getString("usuario", "Usuário não encontrado");
        SalvaDAO sdao = new SalvaDAO(getActivity());
        ArrayList<PessoaSalvaMeta> metasalvas = new ArrayList<PessoaSalvaMeta>();
        metasalvas = sdao.metasSalvas(usuario);

        return metasalvas;
    }


    public void showInputDialog(final Context context, final String user) {
        final AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        LayoutInflater inflater = getActivity().getLayoutInflater();

        //Cria a view a ser utilizada no dialog
        View view = inflater.inflate(R.layout.nova_meta, null);

        //Obtém uma referencia ao Spinner
        Spinner spinner = (Spinner) view.findViewById(R.id.spPeriodo);
        Spinner spinner2 = (Spinner) view.findViewById(R.id.spPublicar);
        final EditText desc = (EditText) view.findViewById(R.id.desc);

        //Cria o Adapter
        ArrayAdapter adapter = ArrayAdapter.createFromResource(context, R.array.periodo,
                android.R.layout.simple_spinner_dropdown_item);//ou android.R.layout.simple_spinner_item
        ArrayAdapter adapter2 = ArrayAdapter.createFromResource(context, R.array.publicar,
                android.R.layout.simple_spinner_dropdown_item);//ou android.R.layout.simple_spinner_item

        //Atribui o adapter ao spinner
        spinner.setAdapter(adapter);
        spinner2.setAdapter(adapter2);

        final int[] pe = {0};
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(adapterView.getItemAtPosition(i).toString()!= null) {
                    if (adapterView.getItemAtPosition(i).toString().equals("1 semana"))
                        pe[0] = 7;
                    if (adapterView.getItemAtPosition(i).toString().equals("10 dias"))
                        pe[0] = 10;
                    if (adapterView.getItemAtPosition(i).toString().equals("1 mês"))
                        pe[0] = 30;
                    if (adapterView.getItemAtPosition(i).toString().equals("2 meses"))
                        pe[0] = 60;
                    if (adapterView.getItemAtPosition(i).toString().equals("3 meses"))
                        pe[0] = 90;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }});

        final String[] publi = {""};
        spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

                if(adapterView.getItemAtPosition(i).toString()!= null)
                    publi[0] = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                }
            });

        final SharedPreferences sharedPreferences =  getContext().getSharedPreferences("10lifegoals", Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor;
        editor = sharedPreferences.edit(); //Escrever dentro do arquivo

        final int j = getN();
        alertDialog.setView(view)
                .setPositiveButton("Salvar", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int id) {
                         mdao.criarMeta(desc.getText().toString(), publi[0], pe[0], "N", user);

                        editor.putString("meta "+j,desc.getText().toString());
                        if(pe[0] == 7)
                            editor.putString("pe "+j, "1 semana");
                        if(pe[0] == 10)
                            editor.putString("pe "+j, "10 dias");
                        if(pe[0] == 30)
                            editor.putString("pe "+j, "1 mês");
                        if(pe[0] == 60)
                            editor.putString("pe "+j, "2 meses");
                        if(pe[0] == 90)
                            editor.putString("pe "+j, "3 meses");
                        editor.commit();
                        lstConcluida.requestLayout();

                        Intent i = new Intent(getActivity(), MainActivity.class);
                        startActivity(i);

                    }
                })
        .setNegativeButton("Cancelar", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });

        lstConcluida.requestLayout();
        editor.commit();
        alertDialog.show();
    }

    public void novaMeta(int i){
        this.na=i;
    }

    public int getN(){
        return na;
    }

    public void concluidas(String m, int i){
        final SharedPreferences sharedPreferences =  getContext().getSharedPreferences("10lifegoals", Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor;
        editor = sharedPreferences.edit(); //Escrever dentro do arquivo

        editor.putString("concluida "+i, m);

        editor.commit();
    }
}
