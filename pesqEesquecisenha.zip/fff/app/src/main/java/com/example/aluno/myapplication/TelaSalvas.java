package com.example.aluno.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;

public class TelaSalvas extends ArrayAdapter<PessoaSalvaMeta> {
    private final Context context;
    private final ArrayList<PessoaSalvaMeta> salvas;
    private TextView txtUsuCriador;
    private TextView txtDescrMeta;


    public TelaSalvas(Context context, ArrayList<PessoaSalvaMeta> metasalvas){
        super(context,R.layout.linha_metasalvas, metasalvas);
        this.context = context;
        this.salvas = metasalvas;

    }

    public View getView(int position, View convertView, ViewGroup parent){
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = inflater.inflate(R.layout.linha_metasalvas,parent,false);

        txtUsuCriador = (TextView) rowView.findViewById(R.id.txtUsuCriador);
        txtDescrMeta = (TextView) rowView.findViewById(R.id.txtDescrMeta);

        txtUsuCriador.setText(salvas.get(position).getUsuarioCriador());
        txtDescrMeta.setText(salvas.get(position).getDescrMeta());
        return rowView;
    }
}
